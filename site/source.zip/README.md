# Document Extraction

This is an independent portfolio project. The hosted UI is a browser demo with simulated data. It does not claim work for Lazarus AI.

Open `index.html` to try the standalone demo. The `document-extraction/` directory contains the separate backend service.

Run its Dockerfile with `docker build -t document-extraction .` and `docker run -p 8000:8000 document-extraction` from that backend directory. For persistence, mount `/data` for the transaction and pipeline APIs. See the code and root README in the full bundle for details.
